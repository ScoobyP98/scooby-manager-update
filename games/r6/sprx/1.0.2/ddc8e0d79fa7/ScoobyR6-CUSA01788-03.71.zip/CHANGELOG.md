# 1.0.2

- Corrected native visibility scene validation: pawn world +0x108 is the physics scene (vtable +0xb5dd7e8); its +0x10 query interface has vtable +0xb5df848 and method +0x440. The old bridge tested those identities one link too early and rejected the running range. Native query argument remains the physics scene.
- Aim and Triggerbot now require coherent current health-component ownership and active life state; positive-HP inactive targets cannot qualify. Life is rechecked after visibility queries. Unknown or torn life/visibility still rejects the target.
- Added normal/Silent, player/dummy, crosshair, zero-HP, inactive-positive-HP, owner replacement, torn state and respawn regressions.
- Live read-only evidence confirms the target build, all 62 guards and the corrected scene/interface links. Final native query and firing acceptance still requires the updated plugin in a fresh title process.

# Changes — 1.0.1

- Merged Operator labels/icons into one section; removed Visual defaults.
- Target-line preview and watermark remain visible with the menu open.
- Overlays groups Watermark, Open hint, Spectators and Console in that order.
- Tracers retain the newest 64 shots during bursts and preserve a visible pixel
  for head-on rays, with independent Local/Team/Enemy presentation settings.
- PT Sans replaces the old ESP faces, with Latin/Cyrillic 8–40px hinted banks.
- Legacy Closest captures all eligible joints; explicit group masks remain respected.
- Guarded native Aim visibility is connected in runtime and input/shot lanes.

## Included platform work

- Shared Aim / Visuals / Misc / Settings / Testing layout and controller keyboard.
- Named JSON profiles, transactional migration, Delete confirmation, startup
  selection cleanup and persistent deletion of starter profiles.
- Autosave retains dirty data on I/O failure, retries with a delay and suppresses
  repeated error messages. Loading/deleting cancels obsolete save work.
- Five languages, English JSON template export and validated JSON refresh.
- Editable JSON presets; Save theme, Auto save and Refresh above the theme list.
- Per-feature visual fonts, positions, gradients, outlines and independent text.
- Radar/contact controls, gadget/operator icons, crosshair, off-screen arrows,
  skeleton head circles and separate console/spectator presentation.
- Target-line preview works independently of the aim activation key.
- Independent input/shot captures, activation leases, recoil/spread percentages
  and known native-hook reset recovery; console acceptance remains open.
- Positive Hostage classification, typed gadget AABB boxes and guarded glow
  cleanup; see the known issues for coverage limits.
- Rechecked bone-table batches reduce the full-skeleton fixture's reads from
  291 to 214. Identical-output text layout/rasterization uses 54.9% less host CPU
  in the recorded comparison. Settings navigation avoids serialization.
- Release manifest, checksums, static verification report, installation guide,
  known issues and archive integrity verification are bundled.
