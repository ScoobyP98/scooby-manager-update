# Known issues — 1.0.1

This maintenance release includes documented native-provider limitations. Full console acceptance is incomplete.

## Missing native providers

- Aimbot/Triggerbot Vischeck is bound behind callback/thread/TLS guards. Clear,
  occluded and invalid native outcomes still need controlled console acceptance.
  Failed or unknown measurements cannot qualify as visible.
- Real spectator detection is unfinished. The overlay cannot yet identify
  remote players directly watching you.
- Bomb classification, Hostage's resource-backed branch, non-AABB gadget bounds,
  current gadget paths/effect footprints, wall properties, engine hitbox
  geometry and camera-mode controls remain incomplete.

Unavailable data is reported honestly. A dead teammate or camera user is not
treated as a spectator, and a failed objective classification is not a Bomb.

## Connected features awaiting console acceptance

Lock On, Silent, Triggerbot, recoil/spread, Hostage classification, native glow
and gadget AABB boxes are connected and host-tested. Their final-build behavior
still needs controlled console checks after a full title restart. Triggerbot
uses approximate pose spheres/capsules rather than authoritative engine traces.

Player motion/crouch/prone ESP, all label placements, Russian glyph appearance,
save/restart behavior, transitions and long-session stability require final
console acceptance. Synthetic tests and FTP readback do not establish these.

The skeleton/read and text CPU optimizations have measured host improvements.
PT Sans uses independently hinted pixel banks and premerged outlines. Host
fixtures show fewer scanlines; zero FPS
drops or a particular console frame rate are not guaranteed.

Testing → Unlocks is session-only client behavior. Permanent inventory grants
and complete operator/cosmetic equip coverage are not established.
