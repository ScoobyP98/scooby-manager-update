# Bundled artwork

Operator vectors: [zerobertoo/r6operators](https://github.com/zerobertoo/r6operators),
including Marco Vockner and the r6operators contributors. The MIT license is
included in OPERATORS-LICENSE.txt. See sources.json for pinned revisions and
individual download URLs.

Gadget artwork: [nanoKdR6/R6TAC](https://github.com/nanoKdR6/R6TAC), whose README
credits Strife Tactics and Ubisoft's official Rainbow Six Siege website for gadget
icons. Rainbow Six names and marks belong to Ubisoft and their respective owners.

The build converts source artwork to small, cropped static bitmaps. Exact
available gadget art is mapped explicitly; other classified types use a category
icon. There is no network access, image decoder or texture upload during gameplay.

ESP text uses embedded Noto Sans at 13px and 11px, under the SIL Open Font
License 1.1. The transfer archive includes OFL.txt.
