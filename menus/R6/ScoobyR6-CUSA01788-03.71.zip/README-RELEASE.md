# ScoobyR6 1.0.1

Maintenance release for Rainbow Six Siege **CUSA01788 (EU), version 03.71**.
Use the exact supported executable. Other regions/builds are unsupported.
Read [KNOWN-ISSUES.md](KNOWN-ISSUES.md) before installing: this build still
has unfinished native providers and has not completed console acceptance.

## Install or update

1. Fully close Siege before replacing an existing plugin.
2. Copy `ScoobyR6.sprx` to `/data/GoldHEN/plugins/ScoobyR6.sprx`.
3. Copy the bundled Scooby PNG to `/user/data/Scooby/R6/assets/notification/`,
   retaining its filename. Create the folders if necessary; use mode 0644.
4. Merge the bundled `plugins.ini` fragment into `/data/GoldHEN/plugins.ini`.
   Preserve other games and plugin entries. Keep one ScoobyR6 entry for CUSA01788.
5. Relaunch Siege. Expected startup notifications progress from Loaded to
   Supported title, UI starting, Hook installed and UI active.

An uploaded file does not replace code already loaded in a running title.
To disable the plugin, close Siege and remove its entry from plugins.ini.
Hot unloading is not supported. Keep a backup of your profiles before updating.

## Controls and files

- **R1 + Square:** open/close. **D-pad:** move/adjust. **Cross:** select.
  **Circle:** back/cancel. Numeric values and RGB/Hex fields open the controller
  keyboard; **Square** deletes a character and **R2** accepts entry.
- Root pages: Aim, Visuals, Misc, Settings, Testing. Unlocks is under Testing.
- Settings → Configs: Save, Auto save, Reset defaults, Refresh, Delete and files.
  Load a file to mark it Selected. Delete names that profile and defaults to
  Cancel. Confirming removes JSON/legacy copies and stops that profile's
  autosave; current settings remain applied.
- Settings → UI → Themes: Save theme, Auto save, Refresh and editable files.
  Simple, Light, Slate and High Contrast are seeded as JSON files. Existing
  edits are preserved.
- Settings → Languages: English, German, Spanish, French and Russian. Template
  to file exports English `template.json`; copy to a supported language-code
  JSON, change its code, translate values and choose Refresh.
- The game's file API stores preferences under `/data/Scooby/R6/` in Configs,
  Themes and Languages. The notification PNG uses the global path above.
- Console and spectator overlays are disabled by default. Diagnostics are in
  the console rather than the menu footer.

Manual Save reports success only after the profile and startup-selection marker
are written. Failed autosaves retain pending changes and retry after two seconds;
repeated failures do not flood the console. Save and check the result before
closing the title or changing profiles.

## Package contents and integrity

`release-manifest.json` identifies the target, release version and each file's
SHA-256/size. `CHECKSUMS.sha256` also covers the manifest. `VERIFICATION.json`
records the build's static artifact checks. The adjacent ZIP SHA-256 file covers
the archive. Checksums detect changed files; they are not a publisher signature.

See [CHANGELOG.md](CHANGELOG.md) for this release's changes and the bundled
font/icon licenses for asset terms. Distribution does not include game images,
reference SPRX files, captures, personal configs or development logs.
